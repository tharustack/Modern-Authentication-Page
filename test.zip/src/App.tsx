import React from 'react';
import AuthPage from './components/AuthPage';

function App() {
  return <AuthPage />;
}

export default App;